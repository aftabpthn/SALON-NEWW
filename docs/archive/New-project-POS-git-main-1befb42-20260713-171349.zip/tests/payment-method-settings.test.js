import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const read = (path) => readFileSync(path, "utf8");
const escaped = (label) => new RegExp(label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));

test("payment method settings backend is wired through existing settings table", () => {
  const app = read("server/app.js");
  const route = read("server/routes/payment-method-settings.routes.js");
  const service = read("server/services/payment-method-settings.service.js");

  assert.match(route, /"\/settings\/payment-methods"/, "payment method settings route should exist");
  assert.match(route, /requirePermission\("read",\s*\(\) => "settings"\)/, "read route should require settings permission");
  assert.match(route, /requirePermission\("write",\s*\(\) => "settings"\)/, "write route should require settings permission");
  assert.match(app, /paymentMethodSettingsRouter/, "app should import payment method settings router");
  assert.match(app, /app\.use\("\/api\/v1",\s*paymentMethodSettingsRouter\)/, "v1 API should mount payment method settings");
  assert.match(app, /app\.use\("\/api",\s*paymentMethodSettingsRouter\)/, "legacy API should mount payment method settings");

  assert.match(service, /FROM settings WHERE tenantId = @tenantId AND key = @key/, "service should read existing settings table");
  assert.match(service, /INSERT INTO settings/, "service should save to existing settings table");
  assert.match(service, /ON CONFLICT\(tenantId, key\)/, "service should upsert tenant setting");
  assert.match(service, /tenantService\.assertBranchAccess/, "branch access should be preserved");
  assert.match(service, /cash/, "cash mode should be stored");
  assert.match(service, /allowSplitPayment/, "split payment rule should be stored");
  assert.match(service, /partialPaymentAllowed/, "partial payment rule should be stored");
  assert.match(service, /duePaymentMode/, "due payment mode should be stored");
  assert.match(service, /refundMode/, "refund mode should be stored");
  assert.match(service, /cardSettlementRequired/, "card settlement rule should be stored");
  assert.match(service, /upiTransactionIdRequired/, "UPI transaction id rule should be stored");
  assert.match(service, /ownerApprovalForHighDueRefund/, "owner approval rule should be stored");
  assert.doesNotMatch(service, /CREATE TABLE|ALTER TABLE|server\/db\.js/, "service should not require db schema changes");
});

test("payment method settings frontend exposes POS payment policy controls", () => {
  const routes = read("src/app/app.routes.ts");
  const page = read("src/app/pages/payment-method-settings.component.ts");
  const bill = read("src/app/pages/bill-settings.component.ts");
  const booking = read("src/app/pages/booking-settings.component.ts");
  const calendar = read("src/app/pages/calendar-settings.component.ts");
  const clients = read("src/app/pages/client-custom-form-settings.component.ts");
  const tax = read("src/app/pages/tax-settings.component.ts");
  const marketplace = read("src/app/pages/marketplace-settings.component.ts");
  const other = read("src/app/pages/other-settings.component.ts");

  assert.match(routes, /pos\/payment-modes/, "existing POS payment modes route should remain");
  assert.match(routes, /settings\/payment-methods/, "Angular settings route should exist");
  for (const sidebar of [bill, booking, calendar, clients, tax, marketplace, other, page]) {
    assert.match(sidebar, /routerLink="\/settings\/payment-methods"/, "settings sidebar should link to payment method settings");
  }

  for (const label of [
    "Payment Methods Settings Control",
    "Payment Modes",
    "Split Payment Rules",
    "Due / Partial Payment",
    "Refund Rules",
    "Card / UPI Settlement",
    "Wallet / Gift Card",
    "POS Billing Behavior",
    "Policy Preview",
    "Cash ON/OFF",
    "Card ON/OFF",
    "UPI ON/OFF",
    "Wallet ON/OFF",
    "Gift Card ON/OFF",
    "Split Payment allow/block",
    "Partial payment allow/block",
    "Due payment allow/warn/block",
    "Refund to original mode / cash / wallet",
    "Card settlement required",
    "UPI transaction ID required",
    "Payment note required for due/refund",
    "Owner approval for high due/refund",
    "Manage POS Modes",
    "Save"
  ]) {
    assert.match(page, escaped(label), `missing UI label ${label}`);
  }

  assert.match(page, /v1\/settings\/payment-methods/, "page should call v1 payment method settings API");
  assert.match(page, /activeModesLabel\(\)/, "policy preview should show active payment modes");
});
