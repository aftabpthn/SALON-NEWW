import cors from "cors";
import express from "express";
import rateLimit from "express-rate-limit";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { dataDir } from "./db.js";
import { ensureHappyHoursInvoiceColumns } from "./migrations/add-happy-hours-to-invoices.js";
import "./jobs/flash-sale-monitor.js";
import "./jobs/demand-snapshot.job.js";
import "./jobs/offer-auto-sunset.job.js";
import "./jobs/migration-large-import.worker.js";
import "./jobs/daily-report-email.job.js";
import { env } from "./config/env.js";
import { initializeDatabaseRuntime } from "./utils/db-init.js";
import { ensureAppointmentSystemSchema } from "./services/appointment-schema.service.js";
import { ensureAppointmentActivitySchema } from "./services/appointment-activity-schema.service.js";
import { ensureEnterpriseSchedulerSchema } from "./services/enterprise-scheduler-schema.service.js";
import { ensureClientMasterSchema } from "./services/client-master-schema.service.js";
import { ensureStaffOsSchema } from "./services/staff-os-schema.service.js";
import { ensureStatutoryComplianceSchema } from "./services/compliance/compliance-schema.service.js";
import { ensureInvoiceNotificationSchema } from "./services/invoice-notification-schema.service.js";
import { ensureReputationSchema } from "./services/reputation/reputation-schema.service.js";
import { ensureAccountMasterSchema } from "./services/account-master-schema.service.js";
import { ensureAccountLedgerSchema } from "./services/account-ledger-schema.service.js";
import { ensureTransactionsSchema } from "./services/transactions-schema.service.js";
import { ensureBalanceSheetSchema } from "./services/balance-sheet-schema.service.js";
import { ensureHardeningSchema } from "./services/balance-sheet-hardening-schema.service.js";
import { ensureAdvancedSchema } from "./services/balance-sheet-advanced-schema.service.js";
import { ensureAiWorkforceOsSchema } from "./services/ai-workforce/ai-workforce-schema.service.js";
import { ensureSupplierCommandSchema } from "./services/supplier-command-schema.service.js";
import { ensureEngagementSchema } from "./services/engagement-schema.service.js";
import { ensurePurchaseBillDraftSchema } from "./services/purchase-bill-schema.service.js";
import { ensureProductUnitSchema } from "./services/inventory-enterprise.service.js";
import { ensureInvoicePaymentCollectionSchema } from "./services/invoice-payment-collection-schema.service.js";
import { ensureBillingCompatibilitySchema } from "./services/billing-compatibility-schema.service.js";
import { ensureCashDrawerEodSchema } from "./services/cash-drawer-eod-schema.service.js";
import { ensureGrowthRankBotSchema } from "./services/growth-rank-bot-schema.service.js";
import { ensureLegacyRevenueSchema } from "./services/legacy-revenue-schema.service.js";
import { ensureWaitlistSchema } from "./services/waitlist-schema.service.js";
import { ensureTwoFactorSchema } from "./services/two-factor-schema.service.js";
import { ensureSecurityAlertsSchema } from "./services/security-alerts-schema.service.js";
import { ensureSecurityBlocklistSchema } from "./services/security-blocklist-schema.service.js";
import { ensureSecurityAdvancedSchema } from "./services/security-advanced-schema.service.js";
import { ensureSecurityRateLimitSchema } from "./services/security-rate-limit-schema.service.js";
import { ensureSecurityRestoreDrillSchema } from "./services/security-restore-drill-schema.service.js";
import { ensureMigrationStagingSchema } from "./services/migration-staging-schema.service.js";
import { ensureMigrationTargetMetadataSchema } from "./services/migration-target-metadata-schema.service.js";
import { ensureMigrationUploadSchema } from "./services/migration-upload-schema.service.js";
import { ensureMigrationApprovalSchema } from "./services/migration.service.js";
import { getSchemaMigrationHealth, initializeSchemaMigrationHealth } from "./services/schema-migration-health.service.js";
import { ensureDashboardSchema } from "./services/dashboard-schema.service.js";
import { ensureCustomerAuthSchema } from "./services/customer-auth-schema.service.js";
import { ensureAuthHardeningSchema } from "./services/auth-hardening-schema.service.js";
import { errorHandler, notFoundHandler } from "./middleware/error-handler.js";
import { authenticateJwt } from "./middleware/auth.js";
import { mobileApiContext } from "./middleware/mobile-response.js";
import { requestContext } from "./middleware/request-context.js";
import { enterpriseSecurity } from "./middleware/security.js";
import { securityBlocklistMiddleware } from "./middleware/security-blocklist.middleware.js";
import { securityHeadersPlus } from "./middleware/security-headers-plus.middleware.js";
import { apiPermissionLock } from "./middleware/api-permission-lock.middleware.js";
import { sensitiveAuditPolicy } from "./middleware/sensitive-audit-policy.js";
import { securityMonitoringAlerts } from "./middleware/security-monitoring-alerts.middleware.js";
import { exportProtectionMiddleware } from "./middleware/export-protection.middleware.js";
import { sessionKillSwitchMiddleware } from "./middleware/session-kill-switch.middleware.js";
import { subscriptionGuardMiddleware } from "./middleware/subscription-guard.middleware.js";
import { authRateLimiter } from "./middleware/api-hardening.js";
import { loginAnomalyDetector } from "./middleware/auth-anomaly.js";
import { fieldRedaction } from "./middleware/field-redaction.js";
import { sessionPolicy } from "./middleware/session-policy.js";
import { csrfProtection } from "./middleware/csrf-protection.middleware.js";
import { persistentFixedWindowRateLimit } from "./middleware/persistent-rate-limit.middleware.js";
import { auditLogMiddleware } from "./middleware/audit-log.middleware.js";
import { idempotencyMiddleware } from "./middleware/idempotency.middleware.js";
import { aiRouter } from "./routes/ai.routes.js";
import { accountMasterRouter } from "./routes/account-master.routes.js";
import { transactionsRouter } from "./routes/transactions.routes.js";
import { balanceSheetRouter } from "./routes/balance-sheet.routes.js";
import { balanceSheetHardeningRouter } from "./routes/balance-sheet-hardening.routes.js";
import { balanceSheetAdvancedRouter } from "./routes/balance-sheet-advanced.routes.js";
import { aiMarketingRouter } from "./routes/ai-marketing.routes.js";
import { growthRankBotRouter } from "./routes/growth-rank-bot.routes.js";
import { analyticsRouter } from "./routes/analytics.routes.js";
import { auditRouter } from "./routes/audit.routes.js";
import { authRouter } from "./routes/auth.routes.js";
import { twoFactorRouter } from "./routes/two-factor.routes.js";
import { mfaPublicRouter, mfaRouter } from "./routes/mfa.routes.js";
import { webauthnPublicRouter, webauthnRouter } from "./routes/webauthn.routes.js";
import { passwordRouter } from "./routes/password.routes.js";
import { stepUpRouter } from "./middleware/step-up.js";
import { securityAlertsRouter } from "./routes/security-alerts.routes.js";
import { securityBlocklistRouter } from "./routes/security-blocklist.routes.js";
import { securityAdvancedRouter } from "./routes/security-advanced.routes.js";
import { securityHoneypotRouter } from "./routes/security-honeypot.routes.js";
import { appointmentSafetyRouter, calendarPublicRouter } from "./routes/appointment-safety.routes.js";
import { appointmentActivityRouter } from "./routes/appointment-activity.routes.js";
import { appointmentSmsRouter } from "./routes/appointment-sms.routes.js";
import { enterpriseSchedulerRouter } from "./routes/enterprise-scheduler.routes.js";
import { billingRouter } from "./routes/billing.routes.js";
import { billingAnalyticsRouter } from "./routes/billing-analytics.routes.js";
import { billingHealthRouter } from "./routes/billing-health.routes.js";
import { bookingPaymentsPublicRouter, bookingPaymentsRouter } from "./routes/booking-payments.routes.js";
import { appointmentDepositGateRouter } from "./routes/appointment-deposit-gate.routes.js";
import { bookingAnalyticsRouter } from "./routes/booking-analytics.routes.js";
import { bookingIntelligenceRouter } from "./routes/booking-intelligence.routes.js";
import { bookingPortalRouter } from "./routes/booking-portal.routes.js";
import { bookingPortalV2Router } from "./routes/booking-portal-v2.routes.js";
import { crmRouter } from "./routes/crm.routes.js";
import { clientMasterRouter } from "./routes/client-master.routes.js";
import { customer360Router } from "./routes/customer-360.routes.js";
import { customerAuthRouter } from "./routes/customer-auth.routes.js";
import { customerMarketplaceRouter } from "./routes/customer-marketplace.routes.js";
import { clientReportsRouter } from "./routes/client-reports.routes.js";
import { dashboardRouter } from "./routes/dashboard.routes.js";
import { commissionRouter } from "./routes/commission.routes.js";
import { statutoryComplianceRouter } from "./routes/compliance.routes.js";
import { corporateBillingRouter } from "./routes/corporate-billing.routes.js";
import { deploymentRouter } from "./routes/deployment.routes.js";
import { discountApprovalRouter } from "./routes/discount-approval.routes.js";
import { discountAuditRouter } from "./routes/discount-audit.routes.js";
import { discountBudgetRouter } from "./routes/discount-budget.routes.js";
import { couponEngineRouter } from "./routes/coupon-engine.routes.js";
import { discountWebhooksRouter } from "./routes/discount-webhooks.routes.js";
import { discountRulesRouter } from "./routes/discount-rules.routes.js";
import { discountSimulationsRouter } from "./routes/discount-simulations.routes.js";
import { discountAnomaliesRouter } from "./routes/discount-anomalies.routes.js";
import { crossBranchAnalyticsRouter } from "./routes/cross-branch-analytics.routes.js";
import { pricingIncrementalityRouter } from "./routes/pricing-incrementality.routes.js";
import { pricingMarketRouter } from "./routes/pricing-market.routes.js";
import { level6ReadinessRouter } from "./routes/level6-readiness.routes.js";
import { yieldRouter } from "./routes/yield.routes.js";
import { clvPricingRouter } from "./routes/clv-pricing.routes.js";
import { federatedLearningRouter } from "./routes/federated-learning.routes.js";
import { demandSignalsRouter } from "./routes/demand-signals.routes.js";
import { orgHierarchyRouter } from "./routes/org-hierarchy.routes.js";
import { policyInheritanceRouter } from "./routes/policy-inheritance.routes.js";
import { whiteLabelRulesRouter } from "./routes/white-label-rules.routes.js";
import { ecosystemRouter } from "./routes/ecosystem.routes.js";
import { enterpriseCommandRouter } from "./routes/enterprise-command.routes.js";
import { engagementRouter } from "./routes/engagement.routes.js";
import { financeEngineRouter } from "./routes/finance-engine.routes.js";
import { futureFeaturesRouter } from "./routes/future-features.routes.js";
import { giftCardRouter } from "./routes/gift-card.routes.js";
import { gstRouter } from "./routes/gst.routes.js";
import { happyHoursCampaignAudiencesRouter } from "./routes/happy-hours-campaign-audiences.routes.js";
import { happyHoursCampaignLinksRouter } from "./routes/happy-hours-campaign-links.routes.js";
import { happyHoursAutoSunsetRouter } from "./routes/happy-hours-auto-sunset.routes.js";
import { happyHoursBranchLeaderboardRouter } from "./routes/happy-hours-branch-leaderboard.routes.js";
import { happyHoursClientReturnTrackerRouter } from "./routes/happy-hours-client-return-tracker.routes.js";
import { happyHoursControlTowerRouter, happyHoursPublicOffersRouter } from "./routes/happy-hours-control-tower.routes.js";
import { happyHoursFraudGuardRouter } from "./routes/happy-hours-fraud-guard.routes.js";
import { happyHoursLifecycleRouter } from "./routes/happy-hours-lifecycle.routes.js";
import { happyHoursOfferHealthRouter } from "./routes/happy-hours-offer-health.routes.js";
import { happyHoursRoiScoreRouter } from "./routes/happy-hours-roi-score.routes.js";
import { happyHoursRouter } from "./routes/happy-hours.routes.js";
import { invoiceLedgerRouter } from "./routes/invoice-ledger.routes.js";
import { invoiceNotificationRouter } from "./routes/invoice-notification.routes.js";
import { inventoryIntelligenceRouter } from "./routes/inventory-intelligence.routes.js";
import { legacyRevenueRouter } from "./routes/legacy-revenue.routes.js";
import { localizationPreferenceRouter } from "./routes/localization-preference.routes.js";
import { liveConsultationRouter } from "./routes/live-consultation.routes.js";
import { membershipEnterpriseRouter } from "./routes/membership-enterprise.routes.js";
import { migrationRouter } from "./routes/migration.routes.js";
import { migrationService } from "./services/migration.service.js";
import { mobileRouter } from "./routes/mobile.routes.js";
import { offlineRouter } from "./routes/offline.routes.js";
import { offlineSyncRouter } from "./routes/offline-sync.routes.js";
import { operationsRouter } from "./routes/operations.routes.js";
import { paymentPublicRouter, paymentRouter } from "./routes/payment.routes.js";
import { posSettingsRouter } from "./routes/pos-settings.routes.js";
import { printDeviceRouter } from "./routes/print-device.routes.js";
import { publicBookingActionsRouter } from "./routes/public-booking-actions.routes.js";
import { publicBookingProfileRouter } from "./routes/public-booking-profile.routes.js";
import { qualityRouter } from "./routes/quality.routes.js";
import { dailyClosingRouter } from "./routes/daily-closing.routes.js";
import { cashDrawerEodPublicRouter, cashDrawerEodRouter } from "./routes/cash-drawer-eod.routes.js";
import { reconciliationRouter } from "./routes/reconciliation.routes.js";
import { reputationPublicRouter, reputationRouter } from "./routes/reputation.routes.js";
import { realtimeRouter } from "./routes/realtime.routes.js";
import { resourceRouter } from "./routes/resource.routes.js";
import { saasRouter } from "./routes/saas.routes.js";
import { salonCostRouter } from "./routes/salon-cost.routes.js";
import { securityRouter } from "./routes/security.routes.js";
import { gdprRouter } from "./routes/gdpr.routes.js";
import { apiKeyRouter } from "./routes/api-key.routes.js";
import { auditChainRouter } from "./routes/audit-chain.routes.js";
import { siemRouter } from "./routes/siem.routes.js";
import { siteLogsRouter } from "./routes/site-logs.routes.js";
import { oversightCommandCenterRouter } from "./routes/oversight-command-center.routes.js";
import { smartBookingRouter } from "./routes/smart-booking.routes.js";
import { slotReservationRouter } from "./routes/slot-reservation.routes.js";
import { staffSalesReportRouter } from "./routes/staff-sales-report.routes.js";
import { staffManagementRouter } from "./routes/staff-management.routes.js";
import { staffOsRouter } from "./routes/staff-os.routes.js";
import { staffEnterpriseRouter } from "./routes/staff-enterprise.routes.js";
import { staffSelfRouter } from "./routes/staff-self.routes.js";
import { superAdminRouter } from "./routes/super-admin.routes.js";
import { terminalRouter } from "./routes/terminal.routes.js";
import { whatsappRouter } from "./routes/whatsapp.routes.js";
import { birthdayCampaignRouter } from "./routes/birthday-campaign.routes.js";
import { waitlistRouter } from "./routes/waitlist.routes.js";
import { whiteLabelRouter } from "./routes/white-label.routes.js";
import { workflowEngineRouter } from "./routes/workflow-engine.routes.js";
import { zReportRouter } from "./routes/z-report.routes.js";

import { ensureDueRecoveryFollowupSchema } from "./services/due-recovery-followup-schema.service.js";
import { ensureProfitActionQueueSchema } from "./services/profit-action-queue-schema.service.js";
import { ensureProfitGovernanceSchema } from "./services/profit-governance-schema.service.js";
import { ensureLocationSharingSchema } from "./services/location-sharing-schema.service.js";
import { ensureLeadManagementSchema } from "./services/lead-management-schema.service.js";
import { appointmentSalonistReportRouter } from "./routes/appointment-salonist-report.routes.js";
import { billSettingsRouter } from "./routes/bill-settings.routes.js";
import { bookingSettingsRouter } from "./routes/booking-settings.routes.js";
import { businessDetailsSettingsRouter } from "./routes/business-details-settings.routes.js";
import { calendarSettingsRouter } from "./routes/calendar-settings.routes.js";
import { clientCustomFormSettingsRouter } from "./routes/client-custom-form-settings.routes.js";
import { consentFormsSettingsRouter } from "./routes/consent-forms-settings.routes.js";
import { customFieldsSettingsRouter } from "./routes/custom-fields-settings.routes.js";
import { dueRecoveryReportRouter } from "./routes/due-recovery-report.routes.js";
import { generalSettingsRouter } from "./routes/general-settings.routes.js";
import { inventorySettingsRouter } from "./routes/inventory-settings.routes.js";
import { laundryEntryRouter } from "./routes/laundry-entry.routes.js";
import { leadManagementRouter } from "./routes/lead-management.routes.js";
import { membershipSettingsRouter } from "./routes/membership-settings.routes.js";
import { messageHistorySettingsRouter } from "./routes/message-history-settings.routes.js";
import { multipleLocationSettingsRouter } from "./routes/multiple-location-settings.routes.js";
import { otherSettingsRouter } from "./routes/other-settings.routes.js";
import { packageSettingsRouter } from "./routes/package-settings.routes.js";
import { paymentMethodSettingsRouter } from "./routes/payment-method-settings.routes.js";
import { pettyCashRouter } from "./routes/petty-cash.routes.js";
import { productSettingsRouter } from "./routes/product-settings.routes.js";
import { securitySettingsRouter } from "./routes/security-settings.routes.js";
import { serviceSettingsRouter } from "./routes/service-settings.routes.js";
import { serviceTrendsReportRouter } from "./routes/service-trends-report.routes.js";
import { smsTemplateSettingsRouter } from "./routes/sms-template-settings.routes.js";
import { supplierSettingsRouter } from "./routes/supplier-settings.routes.js";
import { clientDiscountBrainRouter } from "./routes/client-discount-brain.routes.js";
import { happyHoursBundleAwareRouter } from "./routes/happy-hours-bundle-aware.routes.js";
import { happyHoursChannelAwareRouter } from "./routes/happy-hours-channel-aware.routes.js";
import { happyHoursElasticityRouter } from "./routes/happy-hours-elasticity.routes.js";
import { happyHoursInventoryAwareRouter } from "./routes/happy-hours-inventory-aware.routes.js";
import { happyHoursLeadTimeRouter } from "./routes/happy-hours-lead-time.routes.js";
import { happyHoursMarketAwareRouter } from "./routes/happy-hours-market-aware.routes.js";
import { happyHoursMemberWalletRouter } from "./routes/happy-hours-member-wallet.routes.js";
import { happyHoursNoShowRiskRouter } from "./routes/happy-hours-no-show-risk.routes.js";
import { happyHoursStaffAwareRouter } from "./routes/happy-hours-staff-aware.routes.js";
import { happyHoursWeatherEventRouter } from "./routes/happy-hours-weather-event.routes.js";
import { locationSharingRouter } from "./routes/location-sharing.routes.js";
import { messageHistoryReportRouter } from "./routes/message-history-report.routes.js";
import { marketplaceSettingsRouter } from "./routes/marketplace-settings.routes.js";
import { messageTemplateStudioRouter } from "./routes/message-template-studio.routes.js";
import { pendingPackagesReportRouter } from "./routes/pending-packages-report.routes.js";
import { profitIntelligenceRouter } from "./routes/profit-intelligence.routes.js";
import { salesToolsRouter } from "./routes/sales-tools.routes.js";
import { taxSettingsRouter } from "./routes/tax-settings.routes.js";
import { whatsappWebhookRouter } from "./routes/whatsapp-webhook.routes.js";

function healthPayload(version = "legacy") {
  return { ok: true, service: "Aura Salon CRM/POS API", version, timestamp: new Date().toISOString() };
}

const PROTECTED_REPORT_WINDOW_MS = 60 * 1000;
const PROTECTED_REPORT_LIMIT = 120;

function isPublicMarketplacePath(req) {
  return req.path === "/public" || req.path.startsWith("/public/");
}

const apiV1RateLimiter = persistentFixedWindowRateLimit({
  scope: "api-v1",
  max: 100,
  windowMs: 15 * 60 * 1000,
  applies: (req) => !isPublicMarketplacePath(req),
  keyFn: (req) => [req.ip || "unknown", req.path.split("/").slice(0, 4).join("/")].join(":")
});

const apiV1EdgeRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  skip: isPublicMarketplacePath,
  standardHeaders: true,
  legacyHeaders: false
});

const protectedReportRateLimit = persistentFixedWindowRateLimit({
  scope: "protected-report",
  max: PROTECTED_REPORT_LIMIT,
  windowMs: PROTECTED_REPORT_WINDOW_MS,
  headerPrefix: "x-protected-ratelimit",
  keyFn: (req) => [req.ip || "unknown", req.path.split("/").slice(0, 4).join("/")].join(":")
});

export function createApp() {
  initializeDatabaseRuntime();
  ensureAppointmentSystemSchema();
  ensureAppointmentActivitySchema();
  ensureEnterpriseSchedulerSchema();
  ensureClientMasterSchema();
  ensureStaffOsSchema();
  ensureStatutoryComplianceSchema();
  ensureInvoiceNotificationSchema();
  ensureReputationSchema();
  ensureAccountMasterSchema();
  ensureAccountLedgerSchema();
  ensureTransactionsSchema();
  ensureBalanceSheetSchema();
  ensureHardeningSchema();
  ensureAdvancedSchema();
  ensureAiWorkforceOsSchema();
  ensureSupplierCommandSchema();
  ensureEngagementSchema();
  ensurePurchaseBillDraftSchema();
  ensureProductUnitSchema();
  ensureInvoicePaymentCollectionSchema();
  ensureBillingCompatibilitySchema();
  ensureHappyHoursInvoiceColumns();
  ensureCashDrawerEodSchema();
  ensureGrowthRankBotSchema();
  ensureLegacyRevenueSchema();
  ensureDashboardSchema();
  ensureCustomerAuthSchema();
  ensureWaitlistSchema();
  ensureAuthHardeningSchema();
  ensureTwoFactorSchema();
  ensureSecurityAlertsSchema();
  ensureSecurityBlocklistSchema();
  ensureSecurityAdvancedSchema();
  ensureSecurityRateLimitSchema();
  ensureSecurityRestoreDrillSchema();
  ensureMigrationStagingSchema();
  ensureMigrationTargetMetadataSchema();
  ensureMigrationUploadSchema();
  ensureMigrationApprovalSchema();
  initializeSchemaMigrationHealth();
  ensureDueRecoveryFollowupSchema();
  ensureProfitActionQueueSchema();
  ensureProfitGovernanceSchema();
  ensureLocationSharingSchema();
  ensureLeadManagementSchema();
  const app = express();
  app.disable("x-powered-by");
  app.set("etag", false);
  if (env.trustProxy) app.set("trust proxy", 1);
  app.use(
    cors({
      credentials: true,
      origin: (origin, callback) => {
        const devLocalhost = env.nodeEnv !== "production" && (/^http:\/\/127\.0\.0\.1:\d+$/.test(origin || "") || /^http:\/\/localhost:\d+$/.test(origin || ""));
        if (!origin || env.allowedOrigins.includes(origin) || devLocalhost) {
          callback(null, true);
          return;
        }
        callback(new Error("Origin not allowed by CORS"));
      }
    })
  );
  app.use("/uploads", express.static(join(dataDir, "uploads"), { maxAge: "7d" }));
  const migrationJsonParser = express.json({
    limit: "96mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf?.length ? buf.toString("utf8") : "";
    }
  });
  app.use([
    "/api/v1/migration/normalize-source",
    "/api/migration/normalize-source",
    "/api/v1/migration/uploads",
    "/api/migration/uploads"
  ], (req, res, next) => {
    const path = req.path || "";
    if (path.includes("/uploads/binary") || path.includes("/uploads/sessions/")) return next();
    return migrationJsonParser(req, res, next);
  });
  app.use(express.json({
    limit: env.requestBodyLimit,
    verify: (req, _res, buf) => {
      req.rawBody = buf?.length ? buf.toString("utf8") : "";
    }
  }));
  app.use(requestContext);
  app.use(securityBlocklistMiddleware);
  app.use(enterpriseSecurity);
  app.use(securityHeadersPlus);
  app.use(securityMonitoringAlerts);
  app.use(sensitiveAuditPolicy);
  app.use(securityHoneypotRouter);
  app.use("/api", (req, res, next) => {
    delete req.headers["if-none-match"];
    delete req.headers["if-modified-since"];
    res.setHeader("Cache-Control", "no-store");
    res.vary("authorization");
    res.vary("x-tenant-id");
    res.vary("x-branch-id");
    next();
  });
  app.use("/api/v1", apiV1EdgeRateLimiter);
  app.use("/api/v1", apiV1RateLimiter);
  app.use("/api/v1", csrfProtection);

  // Public, no-auth probe to confirm the running API has the new analyzer code.
  // Open http://127.0.0.1:4000/api/migration-analyzer-version in a browser:
  // if it returns the version below, the API was restarted with the fixes.
  app.get("/api/migration-analyzer-version", (_req, res) => {
    res.json(migrationService.analyzerVersion());
  });

  app.get("/api/versions", (_req, res) => {
    res.json({
      current: "v1",
      canonicalBase: "/api/v1",
      supported: ["v1"],
      aliases: [{ base: "/api", status: "legacy-compatibility", canonicalBase: "/api/v1" }],
      mobile: "/api/v1"
    });
  });
  app.use("/api/v1", authRateLimiter());
  app.use("/api/v1", loginAnomalyDetector());
  app.use("/api/v1", mobileApiContext);
  app.get("/health", (_req, res) => {
    res.json(healthPayload("root"));
  });
  app.get("/api/health", (_req, res) => {
    res.json(healthPayload("legacy"));
  });
  app.get("/api/v1/health", (_req, res) => {
    res.json(healthPayload("v1"));
  });
  app.use("/api/v1", authRouter);
  app.use("/api/v1", twoFactorRouter);
  app.use("/api/v1", mfaPublicRouter);
  app.use("/api/v1", webauthnPublicRouter);
  app.use("/api/v1", passwordRouter);
  app.use("/api/v1", bookingPortalRouter);
  app.use("/api/v1", bookingPortalV2Router);
  app.use("/api/v1", publicBookingActionsRouter);
  app.use("/api/v1", publicBookingProfileRouter);
  app.use("/api/v1", customerAuthRouter);
  app.use("/api/v1", customerMarketplaceRouter);
  app.use("/api/v1", liveConsultationRouter);
  app.use("/api/v1", bookingPaymentsPublicRouter);
  app.use("/api/v1", paymentPublicRouter);
  app.use("/api/v1", calendarPublicRouter);
  app.use("/api/v1", reputationPublicRouter);
  app.use("/api/v1", billingHealthRouter);
  app.use("/api/v1", cashDrawerEodPublicRouter);
  app.use("/api/v1/happy-hours-offers", happyHoursPublicOffersRouter);
  app.use("/api/v1", authenticateJwt(), auditLogMiddleware);
  app.use("/api/v1", apiPermissionLock);
  app.use("/api/v1", sessionKillSwitchMiddleware);
  app.use("/api/v1", subscriptionGuardMiddleware);
  app.use("/api/v1", fieldRedaction());
  app.use("/api/v1", sessionPolicy());
  app.use("/api/v1", idempotencyMiddleware);
  app.use("/api/v1", exportProtectionMiddleware);
  app.get("/api/v1/admin/schema-health", (req, res) => {
    const role = String(req.access?.role || req.headers["x-user-role"] || "").toLowerCase();
    if (!["owner", "admin", "superadmin"].includes(role)) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    res.json(getSchemaMigrationHealth());
  });
  app.use("/api/v1", dashboardRouter);
  app.use("/api/v1", bookingAnalyticsRouter);
  app.use("/api/v1", bookingIntelligenceRouter);
  app.use("/api/v1", appointmentActivityRouter);
  app.use("/api/v1", appointmentSmsRouter);
  app.use("/api/v1", enterpriseSchedulerRouter);
  app.use("/api/v1", waitlistRouter);
  app.use("/api/v1", accountMasterRouter);
  app.use("/api/v1", transactionsRouter);
  app.use("/api/v1", pettyCashRouter);
  app.use("/api/v1", balanceSheetRouter);
  app.use("/api/v1", balanceSheetHardeningRouter);
  app.use("/api/v1", balanceSheetAdvancedRouter);
  app.use("/api/v1", salonCostRouter);
  app.use("/api/v1", crmRouter);
  app.use("/api/v1", clientMasterRouter);
  app.use("/api/v1", gstRouter);
  app.use("/api/v1", statutoryComplianceRouter);
  app.use("/api/v1", billingRouter);
  app.use("/api/v1", billingAnalyticsRouter);
  app.use("/api/v1", commissionRouter);
  app.use("/api/v1", dailyClosingRouter);
  app.use("/api/v1", cashDrawerEodRouter);
  app.use("/api/v1", reconciliationRouter);
  app.use("/api/v1", offlineSyncRouter);
  app.use("/api/v1", corporateBillingRouter);
  app.use("/api/v1", giftCardRouter);
  app.use("/api/v1/coupon-engine", couponEngineRouter);
  app.use("/api/v1/happy-hours-campaign-audiences", happyHoursCampaignAudiencesRouter);
  app.use("/api/v1/happy-hours-campaign-links", happyHoursCampaignLinksRouter);
  app.use("/api/v1/happy-hours-auto-sunset", happyHoursAutoSunsetRouter);
  app.use("/api/v1/happy-hours-branch-leaderboard", happyHoursBranchLeaderboardRouter);
  app.use("/api/v1/happy-hours-client-returns", happyHoursClientReturnTrackerRouter);
  app.use("/api/v1/happy-hours-control-tower", happyHoursControlTowerRouter);
  app.use("/api/v1/happy-hours-bundle-aware", happyHoursBundleAwareRouter);
  app.use("/api/v1/happy-hours-channel-aware", happyHoursChannelAwareRouter);
  app.use("/api/v1/happy-hours-client-brain", clientDiscountBrainRouter);
  app.use("/api/v1/happy-hours-elasticity", happyHoursElasticityRouter);
  app.use("/api/v1/happy-hours-fraud-guard", happyHoursFraudGuardRouter);
  app.use("/api/v1/happy-hours-inventory-aware", happyHoursInventoryAwareRouter);
  app.use("/api/v1/happy-hours-lead-time", happyHoursLeadTimeRouter);
  app.use("/api/v1/happy-hours-lifecycle", happyHoursLifecycleRouter);
  app.use("/api/v1/happy-hours-market-aware", happyHoursMarketAwareRouter);
  app.use("/api/v1/happy-hours-member-wallet", happyHoursMemberWalletRouter);
  app.use("/api/v1/happy-hours-no-show-risk", happyHoursNoShowRiskRouter);
  app.use("/api/v1/happy-hours-offer-health", happyHoursOfferHealthRouter);
  app.use("/api/v1/happy-hours-roi-score", happyHoursRoiScoreRouter);
  app.use("/api/v1/happy-hours-staff-aware", happyHoursStaffAwareRouter);
  app.use("/api/v1/happy-hours-weather-event", happyHoursWeatherEventRouter);
  app.use("/api/v1", discountApprovalRouter);
  app.use("/api/v1/pricing", pricingIncrementalityRouter);
  app.use("/api/v1/pricing", pricingMarketRouter);
  app.use("/api/v1/pricing", level6ReadinessRouter);
  app.use("/api/v1/pricing", clvPricingRouter);
  app.use("/api/v1/pricing", federatedLearningRouter);
  app.use("/api/v1/yield", yieldRouter);
  app.use("/api/v1", invoiceLedgerRouter);
  app.use("/api/v1", invoiceNotificationRouter);
  app.use("/api/v1", terminalRouter);
  app.use("/api/v1", printDeviceRouter);
  app.use("/api/v1", zReportRouter);
  app.use("/api/v1", paymentRouter);
  app.use("/api/v1", posSettingsRouter);
  app.use("/api/v1", generalSettingsRouter);
  app.use("/api/v1", productSettingsRouter);
  app.use("/api/v1", supplierSettingsRouter);
  app.use("/api/v1", inventorySettingsRouter);
  app.use("/api/v1", smsTemplateSettingsRouter);
  app.use("/api/v1", serviceSettingsRouter);
  app.use("/api/v1", packageSettingsRouter);
  app.use("/api/v1", membershipSettingsRouter);
  app.use("/api/v1", consentFormsSettingsRouter);
  app.use("/api/v1", customFieldsSettingsRouter);
  app.use("/api/v1", calendarSettingsRouter);
  app.use("/api/v1", multipleLocationSettingsRouter);
  app.use("/api/v1", billSettingsRouter);
  app.use("/api/v1", bookingSettingsRouter);
  app.use("/api/v1", businessDetailsSettingsRouter);
  app.use("/api/v1", otherSettingsRouter);
  app.use("/api/v1", paymentMethodSettingsRouter);
  app.use("/api/v1", messageHistorySettingsRouter);
  app.use("/api/v1", securitySettingsRouter);
  app.use("/api/v1", bookingPaymentsRouter);
  app.use("/api/v1", appointmentDepositGateRouter);
  app.use("/api/v1", legacyRevenueRouter);
  app.use("/api/v1", leadManagementRouter);
  app.use("/api/v1", localizationPreferenceRouter);
  app.use("/api/v1", siteLogsRouter);
  app.use("/api/v1", auditRouter);
  app.use("/api/v1", authenticateJwt(), mobileRouter);
  app.use("/api/v1", authenticateJwt(), realtimeRouter);
  app.use("/api/v1", authenticateJwt(), superAdminRouter);
  app.use("/api/v1", authenticateJwt(), saasRouter);
  app.use("/api/v1", authenticateJwt(), smartBookingRouter);
  app.use("/api/v1", securityAlertsRouter);
  app.use("/api/v1", securityBlocklistRouter);
  app.use("/api/v1", securityAdvancedRouter);
  app.use("/api/v1", authenticateJwt(), securityRouter);
  app.use("/api/v1", authenticateJwt(), gdprRouter);
  app.use("/api/v1", authenticateJwt(), apiKeyRouter);
  app.use("/api/v1", authenticateJwt(), auditChainRouter);
  app.use("/api/v1", authenticateJwt(), siemRouter);
  app.use("/api/v1", authenticateJwt(), oversightCommandCenterRouter);
  app.use("/api/v1", mfaRouter);
  app.use("/api/v1", webauthnRouter);
  app.use("/api/v1", authenticateJwt(), stepUpRouter);
  app.use("/api/v1", authenticateJwt(), offlineRouter);
  app.use("/api/v1", authenticateJwt(), whiteLabelRouter);
  app.use("/api/v1", authenticateJwt(), futureFeaturesRouter);
  app.use("/api/v1", authenticateJwt(), workflowEngineRouter);
  app.use("/api/v1", authenticateJwt(), financeEngineRouter);
  app.use("/api/v1", authenticateJwt(), customer360Router);
  app.use("/api/v1", authenticateJwt(), qualityRouter);
  app.use("/api/v1", authenticateJwt(), deploymentRouter);
  app.use("/api/v1", authenticateJwt(), ecosystemRouter);
  app.use("/api/v1", authenticateJwt(), analyticsRouter);
  app.use("/api/v1", authenticateJwt(), migrationRouter);
  app.use("/api/v1", authenticateJwt(), aiRouter);
  app.use("/api/v1", authenticateJwt(), aiMarketingRouter);
  app.use("/api/v1", authenticateJwt(), growthRankBotRouter);
  app.use("/api/v1", authenticateJwt(), whatsappRouter);
  app.use("/api/v1", authenticateJwt(), birthdayCampaignRouter);
  app.use("/api/v1", authenticateJwt(), staffManagementRouter);
  app.use("/api/v1", authenticateJwt(), staffOsRouter);
  app.use("/api/v1", authenticateJwt(), staffEnterpriseRouter);
  app.use("/api/v1", authenticateJwt(), staffSelfRouter);
  app.use("/api/v1", authenticateJwt(), enterpriseCommandRouter);
  app.use("/api/v1", authenticateJwt(), engagementRouter);
  app.use("/api/v1", authenticateJwt(), inventoryIntelligenceRouter);
  app.use("/api/v1", apiV1RateLimiter, authenticateJwt(), laundryEntryRouter);
  app.use("/api/v1", authenticateJwt(), membershipEnterpriseRouter);
  app.use("/api/v1", authenticateJwt(), staffSalesReportRouter);
  app.use("/api/v1", authenticateJwt(), clientReportsRouter);
  app.use("/api/v1", authenticateJwt(), appointmentSafetyRouter);
  app.use("/api/v1", authenticateJwt(), operationsRouter);
  app.use("/api/v1", authenticateJwt(), slotReservationRouter);
  app.use("/api/v1", authenticateJwt(), appointmentSafetyRouter);
  app.use("/api/v1", authenticateJwt(), reputationRouter);
  app.use("/api/v1", authenticateJwt(), resourceRouter);
  app.use("/api/v1", appointmentSalonistReportRouter);
  app.use("/api/v1", dueRecoveryReportRouter);
  app.use("/api/v1", pendingPackagesReportRouter);
  app.use("/api/v1", serviceTrendsReportRouter);
  app.use("/api/v1", locationSharingRouter);
  app.use("/api/v1", taxSettingsRouter);
  app.use("/api/v1", clientCustomFormSettingsRouter);
  app.use("/api/v1", marketplaceSettingsRouter);
  app.use("/api/v1", authenticateJwt(), profitIntelligenceRouter);
  app.use("/api/v1", protectedReportRateLimit, authenticateJwt(), messageHistoryReportRouter);
  app.use("/api/v1", protectedReportRateLimit, authenticateJwt(), messageTemplateStudioRouter);
  app.use("/api/v1", protectedReportRateLimit, authenticateJwt(), salesToolsRouter);
  app.use("/api/v1", notFoundHandler);

  app.get("/", (_req, res) => {
    res.json({
      ok: true,
      service: "Aura Salon CRM/POS API",
      message: "API server is running. Open the Angular apps from their dev-server ports.",
      links: {
        health: "/api/health",
        versions: "/api/versions",
        app: "http://127.0.0.1:4300",
        customerApp: "http://127.0.0.1:4310"
      },
      timestamp: new Date().toISOString()
    });
  });


  const legacyApiAuth = env.allowLegacyApiAuthBypass ? (_req, _res, next) => next() : authenticateJwt();
  app.use("/api", calendarPublicRouter);
  app.use("/api", bookingPaymentsPublicRouter);
  app.use("/api", paymentPublicRouter);
  app.use("/api", publicBookingActionsRouter);
  app.use("/api", publicBookingProfileRouter);
  app.use("/api", customerAuthRouter);
  app.use("/api", customerMarketplaceRouter);
  app.use("/api", liveConsultationRouter);
  app.use("/api", reputationPublicRouter);
  app.use("/api", billingHealthRouter);
  app.use("/api", cashDrawerEodPublicRouter);
  app.use("/api", staffSelfRouter);
  app.use("/api/happy-hours-offers", happyHoursPublicOffersRouter);
  app.use("/api/happy-hours", happyHoursRouter);
  app.use("/api", legacyApiAuth);
  app.use("/api", auditLogMiddleware);
  app.use("/api", apiPermissionLock);
  app.use("/api", sessionKillSwitchMiddleware);
  app.use("/api", subscriptionGuardMiddleware);
  app.use("/api", idempotencyMiddleware);
  app.use("/api", exportProtectionMiddleware);
  app.use("/api/discount-audit", discountAuditRouter);
  app.use("/api/discount-budget", discountBudgetRouter);
  app.use("/api/coupon-engine", couponEngineRouter);
  app.use("/api/discount-webhooks", discountWebhooksRouter);
  app.use("/api/discount-rules", discountRulesRouter);
  app.use("/api/discount-simulations", discountSimulationsRouter);
  app.use("/api/discount-anomalies", discountAnomaliesRouter);
  app.use("/api/cross-branch-analytics", crossBranchAnalyticsRouter);
  app.use("/api/pricing", pricingIncrementalityRouter);
  app.use("/api/pricing", pricingMarketRouter);
  app.use("/api/pricing", level6ReadinessRouter);
  app.use("/api/pricing", clvPricingRouter);
  app.use("/api/pricing", federatedLearningRouter);
  app.use("/api/yield", yieldRouter);
  app.use("/api/happy-hours-auto-sunset", happyHoursAutoSunsetRouter);
  app.use("/api/happy-hours-branch-leaderboard", happyHoursBranchLeaderboardRouter);
  app.use("/api/happy-hours-client-returns", happyHoursClientReturnTrackerRouter);
  app.use("/api/happy-hours-control-tower", happyHoursControlTowerRouter);
  app.use("/api/happy-hours-bundle-aware", happyHoursBundleAwareRouter);
  app.use("/api/happy-hours-channel-aware", happyHoursChannelAwareRouter);
  app.use("/api/happy-hours-client-brain", clientDiscountBrainRouter);
  app.use("/api/happy-hours-elasticity", happyHoursElasticityRouter);
  app.use("/api/happy-hours-fraud-guard", happyHoursFraudGuardRouter);
  app.use("/api/happy-hours-inventory-aware", happyHoursInventoryAwareRouter);
  app.use("/api/happy-hours-lead-time", happyHoursLeadTimeRouter);
  app.use("/api/happy-hours-lifecycle", happyHoursLifecycleRouter);
  app.use("/api/happy-hours-market-aware", happyHoursMarketAwareRouter);
  app.use("/api/happy-hours-member-wallet", happyHoursMemberWalletRouter);
  app.use("/api/happy-hours-no-show-risk", happyHoursNoShowRiskRouter);
  app.use("/api/happy-hours-offer-health", happyHoursOfferHealthRouter);
  app.use("/api/happy-hours-roi-score", happyHoursRoiScoreRouter);
  app.use("/api/happy-hours-staff-aware", happyHoursStaffAwareRouter);
  app.use("/api/happy-hours-weather-event", happyHoursWeatherEventRouter);
  app.use("/api/happy-hours-campaign-audiences", happyHoursCampaignAudiencesRouter);
  app.use("/api/demand-signals", demandSignalsRouter);
  app.use("/api/org-hierarchy", orgHierarchyRouter);
  app.use("/api/policy-inheritance", policyInheritanceRouter);
  app.use("/api/white-label-rules", whiteLabelRulesRouter);
  app.use("/api", dashboardRouter);
  app.use("/api", bookingAnalyticsRouter);
  app.use("/api", bookingIntelligenceRouter);
  app.use("/api", appointmentActivityRouter);
  app.use("/api", appointmentSmsRouter);
  app.use("/api", enterpriseSchedulerRouter);
  app.use("/api", accountMasterRouter);
  app.use("/api", transactionsRouter);
  app.use("/api", pettyCashRouter);
  app.use("/api", balanceSheetRouter);
  app.use("/api", balanceSheetHardeningRouter);
  app.use("/api", balanceSheetAdvancedRouter);
  app.use("/api", salonCostRouter);
  app.use("/api", crmRouter);
  app.use("/api", clientMasterRouter);
  app.use("/api", gstRouter);
  app.use("/api", statutoryComplianceRouter);
  app.use("/api", billingRouter);
  app.use("/api", billingAnalyticsRouter);
  app.use("/api", commissionRouter);
  app.use("/api", dailyClosingRouter);
  app.use("/api", cashDrawerEodRouter);
  app.use("/api", reconciliationRouter);
  app.use("/api", offlineSyncRouter);
  app.use("/api", corporateBillingRouter);
  app.use("/api", giftCardRouter);
  app.use("/api/happy-hours-campaign-links", happyHoursCampaignLinksRouter);
  app.use("/api", discountApprovalRouter);
  app.use("/api", invoiceLedgerRouter);
  app.use("/api", invoiceNotificationRouter);
  app.use("/api", terminalRouter);
  app.use("/api", printDeviceRouter);
  app.use("/api", zReportRouter);
  app.use("/api", paymentRouter);
  app.use("/api", posSettingsRouter);
  app.use("/api", generalSettingsRouter);
  app.use("/api", productSettingsRouter);
  app.use("/api", supplierSettingsRouter);
  app.use("/api", inventorySettingsRouter);
  app.use("/api", smsTemplateSettingsRouter);
  app.use("/api", serviceSettingsRouter);
  app.use("/api", packageSettingsRouter);
  app.use("/api", membershipSettingsRouter);
  app.use("/api", consentFormsSettingsRouter);
  app.use("/api", customFieldsSettingsRouter);
  app.use("/api", calendarSettingsRouter);
  app.use("/api", multipleLocationSettingsRouter);
  app.use("/api", billSettingsRouter);
  app.use("/api", bookingSettingsRouter);
  app.use("/api", businessDetailsSettingsRouter);
  app.use("/api", otherSettingsRouter);
  app.use("/api", paymentMethodSettingsRouter);
  app.use("/api", messageHistorySettingsRouter);
  app.use("/api", securitySettingsRouter);
  app.use("/api", bookingPaymentsRouter);
  app.use("/api", appointmentDepositGateRouter);
  app.use("/api", legacyRevenueRouter);
  app.use("/api", leadManagementRouter);
  app.use("/api", localizationPreferenceRouter);
  app.use("/api", siteLogsRouter);
  app.use("/api", auditRouter);
  app.use("/api", oversightCommandCenterRouter);
  app.use("/api", superAdminRouter);
  app.use("/api", saasRouter);
  app.use("/api", smartBookingRouter);
  app.use("/api", twoFactorRouter);
  app.use("/api", securityAlertsRouter);
  app.use("/api", securityBlocklistRouter);
  app.use("/api", securityAdvancedRouter);
  app.use("/api", securityRouter);
  app.use("/api", offlineRouter);
  app.use("/api", whiteLabelRouter);
  app.use("/api", futureFeaturesRouter);
  app.use("/api", workflowEngineRouter);
  app.use("/api", financeEngineRouter);
  app.use("/api", customer360Router);
  app.use("/api", bookingPortalRouter);
  app.use("/api", bookingPortalV2Router);
  app.use("/api", qualityRouter);
  app.use("/api", deploymentRouter);
  app.use("/api", ecosystemRouter);
  app.use("/api", analyticsRouter);
  app.use("/api", authenticateJwt(), migrationRouter);
  app.use("/api", aiRouter);
  app.use("/api", aiMarketingRouter);
  app.use("/api", growthRankBotRouter);
  app.use("/api", whatsappRouter);
  app.use("/api", staffManagementRouter);
  app.use("/api", staffOsRouter);
  app.use("/api", staffEnterpriseRouter);
  app.use("/api", enterpriseCommandRouter);
  app.use("/api", engagementRouter);
  app.use("/api", inventoryIntelligenceRouter);
  app.use("/api", laundryEntryRouter);
  app.use("/api", membershipEnterpriseRouter);
  app.use("/api", staffSalesReportRouter);
  app.use("/api", clientReportsRouter);
  app.use("/api", appointmentSafetyRouter);
  app.use("/api", operationsRouter);
  app.use("/api", slotReservationRouter);
  app.use("/api", appointmentSafetyRouter);
  app.use("/api", reputationRouter);
  app.use("/api", resourceRouter);

  app.use("/api", whatsappWebhookRouter);
  app.use("/api", appointmentSalonistReportRouter);
  app.use("/api", dueRecoveryReportRouter);
  app.use("/api", pendingPackagesReportRouter);
  app.use("/api", serviceTrendsReportRouter);
  app.use("/api", taxSettingsRouter);
  app.use("/api", clientCustomFormSettingsRouter);
  app.use("/api", marketplaceSettingsRouter);
  app.use("/api", locationSharingRouter);
  app.use("/api", profitIntelligenceRouter);
  app.use("/api", migrationRouter);
  app.use("/api", messageHistoryReportRouter);
  app.use("/api", messageTemplateStudioRouter);
  app.use("/api", salesToolsRouter);

  const clientDist = resolveClientDist();
  if (clientDist) {
    app.use(express.static(clientDist));
    app.get(/^(?!\/api).*/, (_req, res) => {
      res.sendFile(join(clientDist, "index.html"));
    });
  }

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

function resolveClientDist() {
  const candidates = [
    join(process.cwd(), "dist", "aura-salon-crm-pos", "browser"),
    join(process.cwd(), "dist", "aura-salon-crm-pos")
  ];
  return candidates.find((candidate) => existsSync(join(candidate, "index.html"))) || "";
}
