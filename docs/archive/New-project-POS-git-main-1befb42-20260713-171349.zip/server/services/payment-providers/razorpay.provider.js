import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { badRequest } from "../../utils/app-error.js";
import { requireWebhookSecret } from "../../utils/webhook-secret.js";
import { createSignedLinkToken } from "../../utils/signed-link.util.js";
import { PaymentProvider } from "./payment-provider.interface.js";

const money = (value) => Math.round((Number(value) || 0) * 100) / 100;
// Fixed Razorpay endpoint. Test vs live is chosen by the API key
// (rzp_test_* / rzp_live_*), never by the URL, so the host is a constant and
// never influenced by request or environment input (no SSRF surface).
const RAZORPAY_API_BASE = "https://api.razorpay.com/v1";
const RAZORPAY_TIMEOUT_MS = Number(process.env.RAZORPAY_API_TIMEOUT_MS || 15000);

function publicBase() {
  return (process.env.PUBLIC_APP_URL || "http://127.0.0.1:4300").replace(/\/$/, "");
}

function razorpayCredentials() {
  const keyId = process.env.RAZORPAY_KEY_ID || "";
  const keySecret = process.env.RAZORPAY_KEY_SECRET || "";
  return keyId && keySecret ? { keyId, keySecret } : null;
}

async function callRazorpayApi(path, body, { keyId, keySecret }) {
  const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
  const response = await fetch(`${RAZORPAY_API_BASE}${path}`, {
    method: "POST",
    headers: {
      authorization: `Basic ${auth}`,
      "content-type": "application/json"
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(RAZORPAY_TIMEOUT_MS)
  });
  const text = await response.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {};
  }
  if (!response.ok) {
    const message = json?.error?.description || `Razorpay API error (${response.status})`;
    throw badRequest(`Razorpay payment link creation failed: ${message}`);
  }
  return json;
}

function parseBody(rawBody) {
  if (typeof rawBody === "string") {
    try {
      return JSON.parse(rawBody || "{}");
    } catch {
      return {};
    }
  }
  return rawBody || {};
}

function safeTimingEqual(left, right) {
  const leftBuffer = Buffer.from(String(left || ""));
  const rightBuffer = Buffer.from(String(right || ""));
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

export class RazorpayProvider extends PaymentProvider {
  constructor() {
    super("razorpay");
  }

  async createPaymentLink({ invoice, amount, expiresAt, customer = {}, notes = {} }) {
    const currency = invoice.currency || "INR";
    const amountPaise = Math.round(money(amount) * 100);
    const credentials = razorpayCredentials();

    // Real Razorpay Payment Links API — returns a genuine rzp.io short URL the
    // customer recognizes and that cannot be forged or amount-tampered.
    if (credentials) {
      const expireBy = expiresAt ? Math.floor(new Date(expiresAt).getTime() / 1000) : undefined;
      const apiResult = await callRazorpayApi("/payment_links", {
        amount: amountPaise,
        currency,
        accept_partial: false,
        reference_id: `${notes.invoice_id || invoice.id || ""}:${randomUUID().slice(0, 8)}`,
        description: notes.invoice_no ? `Invoice ${notes.invoice_no}` : "Salon invoice payment",
        customer: {
          name: customer.name || undefined,
          contact: customer.phone || undefined,
          email: customer.email || undefined
        },
        notify: { sms: false, email: false },
        reminder_enable: false,
        notes,
        ...(expireBy ? { expire_by: expireBy } : {})
      }, credentials);
      return {
        provider: this.name,
        providerLinkId: apiResult.id,
        paymentLink: apiResult.short_url,
        amount: money(amount),
        currency,
        expiresAt,
        providerPayload: {
          mode: "razorpay_live",
          amountPaise,
          currency,
          referenceId: apiResult.reference_id || "",
          status: apiResult.status || "created",
          customer,
          notes
        }
      };
    }

    // No gateway configured — self-hosted fallback link, HMAC-signed so the
    // /payment page can reject forged or amount-tampered URLs.
    const providerLinkId = `plink_${randomUUID().replace(/-/g, "").slice(0, 16)}`;
    const token = createSignedLinkToken({
      tenantId: notes.tenant_id || "",
      invoiceId: notes.invoice_id || invoice.id || "",
      providerLinkId,
      amountPaise,
      expiresAt
    });
    const shortUrl = `${publicBase()}/payment/razorpay/${providerLinkId}?token=${token}`;
    return {
      provider: this.name,
      providerLinkId,
      paymentLink: shortUrl,
      amount: money(amount),
      currency,
      expiresAt,
      providerPayload: {
        mode: "local_provider_stub",
        amountPaise,
        currency,
        signedToken: token,
        customer,
        notes
      }
    };
  }

  verifyWebhook(rawBody, signature) {
    const rawText = typeof rawBody === "string" ? rawBody : JSON.stringify(rawBody || {});
    const secret = requireWebhookSecret("RAZORPAY_WEBHOOK_SECRET", "dev-razorpay-webhook-secret");
    if (!signature) throw badRequest("Missing Razorpay signature");
    const expected = createHmac("sha256", secret).update(rawText).digest("hex");
    if (!safeTimingEqual(expected, signature)) throw badRequest("Invalid Razorpay webhook signature");
    return {
      verified: true,
      mode: process.env.RAZORPAY_WEBHOOK_SECRET ? "hmac" : "dev_hmac",
      payloadHash: createHash("sha256").update(rawText).digest("hex")
    };
  }

  parseWebhookEvent(rawBody) {
    const body = parseBody(rawBody);
    const payment = body.payload?.payment?.entity || {};
    const paymentLink = body.payload?.payment_link?.entity || {};
    const order = body.payload?.order?.entity || {};
    const statusText = String(payment.status || paymentLink.status || body.status || "").toLowerCase();
    const eventText = String(body.event || "").toLowerCase();
    const amountPaise = Number(payment.amount ?? paymentLink.amount ?? body.amount ?? 0);
    const providerLinkId = paymentLink.id || payment.notes?.payment_link_id || body.providerLinkId || body.paymentLinkId || "";

    return {
      provider: this.name,
      eventId: body.id || `${body.event || "razorpay"}:${payment.id || providerLinkId || Date.now()}`,
      eventType: body.event || "razorpay.webhook",
      providerPaymentId: payment.id || body.providerPaymentId || "",
      providerOrderId: order.id || payment.order_id || body.providerOrderId || "",
      providerLinkId,
      status: statusText || eventText,
      amount: money(amountPaise / 100),
      paid: eventText.includes("paid") || eventText.includes("captured") || statusText === "paid" || statusText === "captured",
      failed: eventText.includes("failed") || statusText === "failed",
      expired: eventText.includes("expired") || statusText === "expired",
      raw: body
    };
  }

  fetchLinkStatus(link) {
    const isExpired = link.expires_at && new Date(link.expires_at).getTime() < Date.now();
    return {
      provider: this.name,
      providerLinkId: link.provider_link_id,
      status: isExpired && link.status === "pending" ? "expired" : link.status,
      amount: money(link.amount),
      fetchedAt: new Date().toISOString(),
      source: "local_gateway_cache"
    };
  }
}

export const razorpayProvider = new RazorpayProvider();
